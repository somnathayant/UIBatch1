import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions, RequestOptionsArgs } from '@angular/http';
import 'rxjs/Rx';
import{StudentMst} from './student.model';

@Injectable()
export class StudentService {
          url:string;
  constructor(private nativeHttp:Http) {

  }
   getUserDetails1(studentMst:StudentMst) {

     
     alert("In service "+studentMst.studentName);
  }
}
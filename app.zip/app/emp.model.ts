export class Emp{
    empName:string;
    empId:string;
}
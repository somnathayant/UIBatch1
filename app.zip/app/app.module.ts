import { NgModule }      from '@angular/core';
import { FormsModule, ReactiveFormsModule }      from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent }  from './app.component';
import{router} from './app.routing';
import{StudentComponent} from './student.component';
import{EmpComponent}from './EmpReg.component';
import{StudentService} from './student.service';
import {HttpModule, Http, Response, Headers, RequestOptions, RequestOptionsArgs } from '@angular/http';

@NgModule({
  imports:      [ BrowserModule, BrowserAnimationsModule, ReactiveFormsModule,
                  FormsModule ,router,HttpModule],
  declarations: [ AppComponent,StudentComponent,EmpComponent ],
  providers:[],
  bootstrap:    [ AppComponent ]//as first
})
export class AppModule { }

import { Component,OnInit } from '@angular/core';
import { Validators,FormControl,FormGroup,FormBuilder } from '@angular/forms';
import{StudentMst} from './student.model';
import {Router} from "@angular/router";
import{StudentService} from './student.service';

@Component({
  selector: 'parent',
  templateUrl: './student.component.html',
  providers:[StudentService],
  styleUrls: ['./app.component.css']
})
export class StudentComponent implements OnInit { 
            studentForm:FormGroup;
            viewChild:boolean;
            description:string;
            fromChild:string;
        constructor(private fb:FormBuilder,private router: Router,private stService:StudentService){
            alert("ok");
        }
        ngOnInit() {
              this.studentForm = this.fb.group({
                'studentName':new FormControl('',Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(10)])),
                'roll':new FormControl('')
            });
           // alert("ngOnInit");
           this.viewChild=false;
    }
    valueSubmission(student:StudentMst){//same identical property for the formcontrolname
           //alert("Form submission happened "+student.studentName);
          // this.router.navigate(['/emp',student.studentName]);//carry value
         
           // this.router.navigate(['/emp']);//without value
           //this.stService.getUserDetails1(student);
        //this.stService.getUserDetails1(student);
        this.stService.getUserDetails1(student);
          // this.viewChild=true;
           //this.description="from parent";
    }
    fromChildMethod(value:any){
         this.fromChild=value;
    }
   
}
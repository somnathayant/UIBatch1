export class StudentMst {
    studentName:String;
    roll:number;
 }

 

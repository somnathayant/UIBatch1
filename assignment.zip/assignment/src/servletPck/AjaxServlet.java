package servletPck;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class AjaxServlet
 */
@WebServlet("/AjaxServlet")
public class AjaxServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AjaxServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*String userName = request.getParameter("userName");
		if (userName.equals("")) {
			userName = "User name cannot be empty";
		} else if(userName.equals("Mac")){
			userName = "Hello " + userName +" your address is Texus";
		}else if(userName.equals("Anish")){
			userName = "Hello " + userName +" your address is NY";
		}else{
			userName = "Hello " + userName +" your address is Alabama";
		}
		response.setContentType("text/plain");
		response.getWriter().write(userName);
	*/	
		String userName = request.getParameter("userName");
		
		if (userName.equals("Anish")) {
			
		ArrayList <String>cityList = new ArrayList<String>();
		cityList.add(("alabama"));
		cityList.add(("wisconsin"));
		Gson gson = new Gson();
		String json = gson.toJson(cityList);


		response.setContentType("application/json"); 
		response.setCharacterEncoding("utf-8"); 
		System.out.println("===========");
		response.getWriter().write(json);
		}

		if (userName.equals("Viky")) {
			
			ArrayList cityList1 = new ArrayList();
			cityList1.add(("ny"));
			cityList1.add(("dellaware"));
		Gson gson = new Gson();
		String json = gson.toJson(cityList1);


		response.setContentType("application/json"); 
		response.setCharacterEncoding("utf-8"); 
		System.out.println("===========");
		response.getWriter().write(json);
		
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		if (userName.equals("")) {
			userName = "User name cannot be empty";
		} else if(userName.equals("Mac")){
			userName = "Hello " + userName +" your address is Texus";
		}else if(userName.equals("Anish")){
			userName = "Hello " + userName +" your address is NY";
		}else{
			userName = "Hello " + userName +" your address is Alabama";
		}
		response.setContentType("text/plain");
		response.getWriter().write(userName);
		
		
	}

}

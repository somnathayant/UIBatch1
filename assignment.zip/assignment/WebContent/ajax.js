$(document).ready(function() {
	/*$('#userName').blur(function(event) {
		var name = $('#userName').val();
		$.get('AjaxServlet', {
			userName : name
		}, function(responseText) {
			$('#ajaxResponse').text(responseText);
		});
	});*/
	
	$('#emp').change(function(event) {
		alert("Change event triggerd");		
		var name = $('#emp').val();
		
	$.ajax({
		  method: "get",
		  url: "AjaxServlet",
		  data: { userName:name }
		})
		  .done(function(jsonRes) {
			  
			  var option = '';
				for(var i=0;i<jsonRes.length;i++)
		        {
					 option += '<option value="'+ jsonRes[i] + '">' + jsonRes[i] + '</option>';
		           
		        }
				 $("#op1").append(option);
		  })
		  
	});
	
});
